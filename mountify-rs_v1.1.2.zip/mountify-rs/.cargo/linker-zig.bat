@echo off
zig cc %*
